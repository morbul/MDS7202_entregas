# Pipeline train_model

> *Note:* This is a `README.md` boilerplate generated using `Kedro 0.18.11`.

## Overview

<!---
Please describe your modular pipeline here.
-->

## Pipeline inputs

<!---
The list of pipeline inputs.
-->

## Pipeline outputs

<!---
The list of pipeline outputs.
-->
